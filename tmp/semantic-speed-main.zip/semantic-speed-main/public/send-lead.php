<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['error' => 'Method not allowed']);
    http_response_code(405);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

$name     = isset($input['name']) ? trim(strip_tags($input['name'])) : '';
$email    = isset($input['email']) ? trim(strip_tags($input['email'])) : '';
$website  = isset($input['website']) ? trim(strip_tags($input['website'])) : '';
$whatsapp = isset($input['whatsapp']) ? trim(strip_tags($input['whatsapp'])) : '';

if (empty($name) || empty($email) || empty($website) || empty($whatsapp)) {
    echo json_encode(['error' => 'All fields are required']);
    http_response_code(400);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['error' => 'Invalid email address']);
    http_response_code(400);
    exit();
}

$to      = 'naveedganatra1992@gmail.com';
$subject = 'New SEO Lead: ' . $name;

$body = "
<h2>New SEO Quote Request</h2>
<table style='border-collapse:collapse;width:100%;max-width:500px;'>
  <tr><td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>Name</td><td style='padding:8px;border:1px solid #ddd;'>$name</td></tr>
  <tr><td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>Email</td><td style='padding:8px;border:1px solid #ddd;'>$email</td></tr>
  <tr><td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>Website</td><td style='padding:8px;border:1px solid #ddd;'>$website</td></tr>
  <tr><td style='padding:8px;border:1px solid #ddd;font-weight:bold;'>WhatsApp</td><td style='padding:8px;border:1px solid #ddd;'>$whatsapp</td></tr>
</table>
<p style='margin-top:16px;color:#666;'>Sent from seoexpertinkarachi.com lead form</p>
";

$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=UTF-8\r\n";
$headers .= "From: info@seoexpertinkarachi.com\r\n";
$headers .= "Reply-To: $email\r\n";

$sent = mail($to, $subject, $body, $headers);

if ($sent) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Failed to send email']);
    http_response_code(500);
}
?>
